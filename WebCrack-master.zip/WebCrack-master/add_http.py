import sys

if __name__ == "__main__":
    with open(sys.argv[1],"r+") as input,open("add_done.txt","a+") as output:
        for i in input:
            if "http://" not in i and "https://" not in i:
                i = "http://" + i
            output.write(i)